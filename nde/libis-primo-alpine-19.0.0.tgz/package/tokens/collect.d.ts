export type TokenKind = 'color' | 'length' | 'font' | 'other';
export interface TokenEntry {
    /** Custom property name, e.g. `--mat-sys-primary`. */
    name: string;
    /** Group derived from the name, e.g. `mat-sys`. */
    group: string;
    kind: TokenKind;
    /** Resolved value per theme; `default` is the page as loaded. */
    values: Record<string, string>;
}
export interface TokenSnapshot {
    format: 'primo-alpine-tokens@1';
    collectedAt: string;
    url: string;
    /** `vid` of the view the snapshot was taken in, when known. */
    view?: string;
    themes: string[];
    tokens: TokenEntry[];
}
export interface CollectOptions {
    /** Extra theme classes to resolve besides the ones detected in the stylesheets. */
    themeClasses?: string[];
    /** Only keep tokens whose name starts with one of these prefixes. Default: all. */
    prefixes?: string[];
}
/**
 * Collects the CSS custom properties the host page defines on `:root`, `html`, `body` and theme
 * classes, resolved with `getComputedStyle`. Cross-origin stylesheets (fonts) are skipped.
 */
export declare function collectTokens(options?: CollectOptions): TokenSnapshot;
export declare function groupOf(name: string): string;
export declare function kindOf(name: string, value: string): TokenKind;
//# sourceMappingURL=collect.d.ts.map