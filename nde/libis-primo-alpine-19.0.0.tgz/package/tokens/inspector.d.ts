import { CollectOptions } from './collect';
/** The part of Alpine the inspector uses. Passed in, so this entry point does not import the main one. */
export interface InspectorAlpine {
    data<T extends object>(name: string, callback: () => T & ThisType<T>): void;
    initTree(el: Element): void;
    destroyTree(el: Element): void;
    raw<T>(value: T): T;
}
/**
 * Mounts the dev-only token inspector: a searchable grid of the host's CSS custom properties with
 * swatches, type samples and click-to-copy `var(--...)`. "Export JSON" downloads a snapshot for
 * `primo-alpine tokens import`. Returns an unmount function.
 *
 * `providePrimoAlpine({ dev: true })` mounts it on `?ndeTokens=1`; call it yourself with
 * `mountTokenInspector(getAlpine())` otherwise.
 */
export declare function mountTokenInspector(Alpine: InspectorAlpine, options?: CollectOptions): () => void;
//# sourceMappingURL=inspector.d.ts.map