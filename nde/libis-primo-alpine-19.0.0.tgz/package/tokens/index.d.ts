/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@libis/primo-alpine/tokens" />
export * from './public-api';
//# sourceMappingURL=libis-primo-alpine-tokens.d.ts.map