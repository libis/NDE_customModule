export * from './collect';
export { mountTokenInspector } from './inspector';
export type { InspectorAlpine } from './inspector';
//# sourceMappingURL=public-api.d.ts.map