import 'reflect-metadata';
import BundledAlpine from 'alpinejs';
import * as i0 from '@angular/core';
import { InjectionToken, inject, NgZone, Injectable, isSignal, ElementRef, Injector, effect, Input, Directive } from '@angular/core';
import { PrimoStateService } from '@libis/primo-shared-state';
import { TranslateService } from '@ngx-translate/core';
import { merge, combineLatest, map } from 'rxjs';

/** Recursively freezes plain objects and arrays. Leaves class instances (Dates, Maps, ...) alone. */
function deepFreeze(value, seen = new WeakSet()) {
    if (value === null || typeof value !== 'object' || seen.has(value))
        return value;
    const proto = Object.getPrototypeOf(value);
    if (!Array.isArray(value) && proto !== Object.prototype && proto !== null)
        return value;
    seen.add(value);
    for (const key of Object.keys(value)) {
        deepFreeze(value[key], seen);
    }
    return Object.freeze(value);
}
function warn(message, ...extra) {
    console.warn(`[primo-alpine] ${message}`, ...extra);
}

/**
 * Alpine compiles directive expressions with `Object.getPrototypeOf(async function () {}).constructor`.
 * Angular CLI (webpack and esbuild alike) downlevels async/await in every module whenever zone.js
 * is used, so that lookup returns plain `Function`, and every expression then fails with
 * "func.call(...).catch is not a function".
 *
 * Code inside a `new Function` string is never transpiled, so this yields the real constructor
 * whatever the bundler did. (Standard Alpine needs `unsafe-eval` anyway.)
 */
const RealAsyncFunction = new Function('return Object.getPrototypeOf(async function () {}).constructor')();
/**
 * True when this bundle's async functions were downleveled. Our own module is transpiled exactly
 * like Alpine's, so if our `async function` is not a real one, neither is Alpine's.
 */
function asyncIsDownleveled() {
    return Object.getPrototypeOf(async function () { }).constructor !== RealAsyncFunction;
}
/**
 * Whether Alpine's current evaluator fails on a trivial expression. False for the CSP build (its
 * own interpreter) and for bundles that kept native async, so those are never touched.
 */
function alpineEvaluatorIsBroken(Alpine) {
    let broken = false;
    Alpine.setErrorHandler(() => (broken = true));
    let result;
    try {
        result = Alpine.evaluate(document.createElement('div'), '1 + 1');
    }
    catch {
        broken = true;
    }
    Alpine.setErrorHandler(defaultErrorHandler);
    return broken || result !== 2;
}
function defaultErrorHandler(error, el, expression) {
    error = Object.assign(error ?? { message: 'No error message given.' }, { el, expression });
    console.warn(`Alpine Expression Error: ${error.message}\n\n${expression ? `Expression: "${expression}"\n\n` : ''}`, el);
    setTimeout(() => {
        throw error;
    }, 0);
}
/** Alpine's "if (...)" / "let|const" statement wrapping, unchanged. */
function rightSideSafe(expression, asyncWrapper) {
    const trimmed = expression.trim();
    if (/^[\n\s]*if.*\(.*\)/.test(trimmed) || /^(let|const)\s/.test(trimmed)) {
        return asyncWrapper ? `(async()=>{ ${expression} })()` : `(()=>{ ${expression} })()`;
    }
    return expression;
}
/**
 * Replaces Alpine's evaluator and raw evaluator with line-for-line ports of Alpine 3.17's
 * `normalEvaluator` / `normalRawEvaluator` that use the real AsyncFunction.
 *
 * One behaviour cannot be reproduced: Alpine's internal `dontAutoEvaluateFunctions` flag, which
 * only `Alpine.extractProp` sets (for inline bindings read by some plugins). Here functions
 * returned by an expression are always called, which is Alpine's default everywhere else.
 */
function installAsyncSafeEvaluator(Alpine) {
    const A = Alpine;
    let errorHandler = defaultErrorHandler;
    const setErrorHandler = A.setErrorHandler.bind(A);
    A.setErrorHandler = (handler) => {
        errorHandler = handler;
        setErrorHandler(handler);
    };
    const handleError = (error, el, expression) => errorHandler(error, el, expression);
    const memo = {};
    function compile(expression, el) {
        if (memo[expression])
            return memo[expression];
        try {
            const func = new RealAsyncFunction('__self', 'scope', `with (scope) { __self.result = ${rightSideSafe(expression, true)} }; __self.finished = true; return __self.result;`);
            Object.defineProperty(func, 'name', { value: `[Alpine] ${expression}` });
            memo[expression] = func;
            return func;
        }
        catch (error) {
            handleError(error, el, expression);
            return undefined;
        }
    }
    function runIfTypeOfFunction(receiver, value, scope, params = [], el) {
        if (typeof value === 'function') {
            const result = value.apply(scope, params);
            if (result instanceof Promise) {
                result.then((i) => runIfTypeOfFunction(receiver, i, scope, params)).catch((error) => handleError(error, el, value));
            }
            else {
                receiver(result);
            }
        }
        else if (typeof value === 'object' && value instanceof Promise) {
            value.then((i) => receiver(i));
        }
        else {
            receiver(value);
        }
    }
    function fromString(dataStack, expression, el) {
        const func = compile(expression, el);
        return (receiver = () => { }, { scope = {}, params = [], context } = {}) => {
            if (!func)
                return;
            func.result = undefined;
            func.finished = false;
            const completeScope = A.mergeProxies([scope, ...dataStack]);
            const promise = func.call(context, func, completeScope).catch((error) => handleError(error, el, expression));
            if (func.finished) {
                runIfTypeOfFunction(receiver, func.result, completeScope, params, el);
                func.result = undefined;
            }
            else {
                promise
                    .then((result) => runIfTypeOfFunction(receiver, result, completeScope, params, el))
                    .catch((error) => handleError(error, el, expression))
                    .finally(() => (func.result = undefined));
            }
        };
    }
    function fromFunction(dataStack, func) {
        return (receiver = () => { }, { scope = {}, params = [] } = {}) => {
            const result = func.apply(A.mergeProxies([scope, ...dataStack]), params);
            runIfTypeOfFunction(receiver, result);
        };
    }
    function dataStackFor(el) {
        const overriddenMagics = {};
        A.injectMagics(overriddenMagics, el);
        return [overriddenMagics, ...A.closestDataStack(el)];
    }
    A.setEvaluator((el, expression) => {
        const dataStack = dataStackFor(el);
        const evaluator = typeof expression === 'function' ? fromFunction(dataStack, expression) : fromString(dataStack, expression, el);
        return (...args) => {
            try {
                return evaluator(...args);
            }
            catch (error) {
                handleError(error, el, expression);
            }
        };
    });
    A.setRawEvaluator((el, expression, extras = {}) => {
        const scope = A.mergeProxies([extras.scope ?? {}, ...dataStackFor(el)]);
        const params = extras.params ?? [];
        const isAsync = expression.includes('await');
        const Ctor = isAsync ? RealAsyncFunction : Function;
        const func = new Ctor('scope', `with (scope) { let __result = ${rightSideSafe(expression, isAsync)}; return __result }`);
        const result = func.call(extras.context, scope);
        if (!isAsync && typeof result === 'function')
            return result.apply(scope, params);
        return result;
    });
}

const ISLAND = Symbol.for('@libis/primo-alpine:island');
function setIslandState(root, state) {
    root[ISLAND] = state;
}
/** Finds the state of the closest island around `el` (islands can nest). */
function islandStateFor(el) {
    for (let node = el; node; node = node.parentElement) {
        const state = node[ISLAND];
        if (state)
            return state;
    }
    return undefined;
}

const SINGLETON = Symbol.for('@libis/primo-alpine');
const SUPPORTED = /^3\.17\./;
/**
 * Returns the one Alpine instance islands use on this page, registering the primo magics once.
 *
 * Several remotes (central package plus a view package) can each bundle primo-alpine. The first
 * one to run claims the page; the others reuse its Alpine so magics, `Alpine.data` registrations
 * and stores are shared, and nothing is configured twice.
 *
 * `Alpine.start()` is never called: it would observe mutations on the whole Primo document.
 * Islands are initialised and destroyed explicitly with `initTree` / `destroyTree`.
 *
 * When Alpine's evaluator is broken because the bundler downleveled async/await (Angular with
 * zone.js), it is replaced by one that uses the real AsyncFunction; see evaluator.ts.
 */
function getAlpine() {
    const g = globalThis;
    let singleton = g[SINGLETON];
    if (!singleton) {
        const foreign = g.Alpine;
        if (foreign && foreign !== BundledAlpine) {
            warn(`Another Alpine (${foreign.version}) is already on the page (window.Alpine). Islands use their own bundled ${BundledAlpine.version}; avoid mixing them in one DOM tree.`);
        }
        if (!SUPPORTED.test(BundledAlpine.version)) {
            warn(`Alpine ${BundledAlpine.version} is outside the supported range ~3.17.`);
        }
        singleton = { Alpine: BundledAlpine, setups: new WeakSet() };
        // Only when Alpine's own evaluator fails (async downleveled); never for the CSP build.
        if (alpineEvaluatorIsBroken(singleton.Alpine))
            installAsyncSafeEvaluator(singleton.Alpine);
        registerMagics(singleton.Alpine);
        Object.defineProperty(g, SINGLETON, { value: singleton });
    }
    return singleton.Alpine;
}
/** Runs an island's `logic.js` registration once per page, however many instances mount. */
function runSetupOnce(setup) {
    if (!setup)
        return;
    const Alpine = getAlpine();
    const { setups } = globalThis[SINGLETON];
    if (setups.has(setup))
        return;
    setups.add(setup);
    setup(Alpine);
}
function requireIsland(el, name) {
    const state = islandStateFor(el);
    if (!state)
        warn(`${name} used outside an island.`, el);
    return state;
}
function registerMagics(Alpine) {
    Alpine.magic('primo', (el) => requireIsland(el, '$primo')?.context.bridge.view);
    Alpine.magic('hostComponent', (el) => requireIsland(el, '$hostComponent')?.hostComponent);
    Alpine.magic('record', (el) => requireIsland(el, '$record')?.record.read());
    Alpine.magic('t', (el) => {
        const state = requireIsland(el, '$t');
        return (key, params) => state?.context.translate(key, params) ?? key;
    });
    Alpine.magic('asset', (el) => {
        const state = requireIsland(el, '$asset');
        return (path) => state?.context.asset(path) ?? path;
    });
    // x-asset-src="assets/images/logo.png": the value is a literal path, never evaluated (CSP-safe).
    // Sets `href` on <a> and <link>, `src` on everything else.
    Alpine.directive('asset-src', (el, { expression }) => {
        const state = requireIsland(el, 'x-asset-src');
        const tag = el.tagName.toLowerCase();
        const attr = tag === 'a' || tag === 'link' ? 'href' : 'src';
        el.setAttribute(attr, state?.context.asset(expression) ?? expression);
    });
}

/** The state domains `$primo` exposes. Mirrors the `PrimoStateService` facade. */
const PRIMO_DOMAINS = ['search', 'filters', 'user', 'config', 'entity', 'account'];

/**
 * Keys Alpine, Vue reactivity, promises or devtools may probe on any object.
 * They are answered without a warning and never subscribe.
 */
const PROBE_KEYS = new Set(['then', 'toJSON', 'constructor', '$$typeof', 'nodeType', 'asymmetricMatch']);
function selectorName(key) {
    return `select${key.charAt(0).toUpperCase()}${key.slice(1)}$`;
}
/** Lists the `$primo` keys a state service offers: every zero-argument `selectFoo$()` method. */
function selectorKeys(service) {
    const keys = new Set();
    for (let proto = service; proto && proto !== Object.prototype; proto = Object.getPrototypeOf(proto)) {
        for (const name of Object.getOwnPropertyNames(proto)) {
            const match = /^select(.+)\$$/.exec(name);
            const member = service[name];
            if (match && typeof member === 'function' && member.length === 0) {
                keys.add(match[1].charAt(0).toLowerCase() + match[1].slice(1));
            }
        }
    }
    return [...keys].sort();
}
/**
 * Connects `PrimoStateService` observables to Alpine's reactivity.
 *
 * - `$primo.<domain>.<name>` maps to `primo.<domain>.select<Name>$()`.
 * - Subscriptions are lazy (made on first read) and all released when the last island detaches.
 * - Values are kept raw; Alpine tracks a per-key tick counter instead of the value itself.
 * - The view is read-only: assignments and deletes throw.
 */
class PrimoBridge {
    constructor(primo, options) {
        this.primo = primo;
        this.options = options;
        this.entries = new Map();
        this.warned = new Set();
        this.domainViews = new Map();
        this.islands = 0;
        this.ticks = options.reactive({});
        this.view = this.createRootView();
    }
    /** Called by each island when it mounts. */
    attach() {
        this.islands++;
    }
    /** Called by each island when it is destroyed. The last one out releases every subscription. */
    detach() {
        this.islands = Math.max(0, this.islands - 1);
        if (this.islands === 0)
            this.releaseAll();
    }
    /** Keys that currently hold a live subscription (for tests and debugging). */
    get activeKeys() {
        return [...this.entries.entries()].filter(([, e]) => e.subscription && !e.subscription.closed).map(([k]) => k);
    }
    get attachedIslands() {
        return this.islands;
    }
    /** Reads one key, subscribing on first use. Tracked by the calling Alpine effect. */
    read(domain, key) {
        const id = `${domain}.${key}`;
        let entry = this.entries.get(id);
        if (!entry) {
            const selector = this.selector(domain, key);
            if (!selector) {
                if (this.options.dev && !this.warned.has(id)) {
                    this.warned.add(id);
                    warn(`Unknown key $primo.${id}: ${domain} has no ${selectorName(key)}().`, selectorKeys(this.domain(domain)));
                }
                return undefined;
            }
            entry = this.subscribe(id, selector);
        }
        void this.ticks[id]; // register the dependency
        return entry.value;
    }
    subscribe(id, selector) {
        const entry = { value: undefined };
        this.entries.set(id, entry);
        this.ticks[id] = 0;
        // NgRx selects emit synchronously on subscribe. That first value is stored without
        // bumping the tick, because we are usually inside the very effect that is reading it.
        let subscribing = true;
        const run = this.options.runOutside ?? ((fn) => fn());
        entry.subscription = run(() => selector().subscribe({
            next: (value) => {
                entry.value = this.options.dev ? deepFreeze(value) : value;
                if (!subscribing)
                    this.ticks[id]++;
            },
            error: (err) => warn(`$primo.${id} errored; keeping the last value.`, err),
        }));
        subscribing = false;
        return entry;
    }
    releaseAll() {
        for (const entry of this.entries.values())
            entry.subscription?.unsubscribe();
        this.entries.clear();
    }
    domain(domain) {
        return this.primo[domain];
    }
    selector(domain, key) {
        const service = this.domain(domain);
        const fn = service?.[selectorName(key)];
        if (typeof fn !== 'function' || fn.length !== 0)
            return undefined;
        return () => fn.call(service);
    }
    createRootView() {
        return readOnlyProxy('$primo', {
            get: (prop) => (PRIMO_DOMAINS.includes(prop) ? this.domainView(prop) : undefined),
            keys: () => [...PRIMO_DOMAINS],
        });
    }
    domainView(domain) {
        let view = this.domainViews.get(domain);
        if (!view) {
            view = readOnlyProxy(`$primo.${domain}`, {
                get: (prop) => this.read(domain, prop),
                keys: () => selectorKeys(this.domain(domain)),
            });
            this.domainViews.set(domain, view);
        }
        return view;
    }
}
function readOnlyProxy(label, source) {
    const reject = (prop) => {
        throw new TypeError(`${label}.${String(prop)} is read-only. Host state cannot be changed from an island.`);
    };
    return new Proxy(Object.create(null), {
        get(_target, prop) {
            // Tell Vue reactivity (used by Alpine) never to wrap this proxy.
            if (prop === '__v_skip')
                return true;
            if (typeof prop !== 'string' || prop.startsWith('__v_') || PROBE_KEYS.has(prop))
                return undefined;
            return source.get(prop);
        },
        has: (_target, prop) => typeof prop === 'string' && source.keys().includes(prop),
        ownKeys: () => source.keys(),
        getOwnPropertyDescriptor: (_target, prop) => typeof prop === 'string' && source.keys().includes(prop)
            ? { configurable: true, enumerable: true, get: () => source.get(prop) }
            : undefined,
        set: (_target, prop) => reject(prop),
        deleteProperty: (_target, prop) => reject(prop),
        defineProperty: (_target, prop) => reject(prop),
        setPrototypeOf: () => reject('__proto__'),
    });
}

const PRIMO_ALPINE_CONFIG = new InjectionToken('PRIMO_ALPINE_CONFIG');
function providePrimoAlpine(config) {
    return [{ provide: PRIMO_ALPINE_CONFIG, useValue: config }];
}
/**
 * Per-remote services the islands share: the `$primo` bridge, translation and asset resolution.
 * One instance per remote injector; the Alpine instance itself is shared page-wide.
 */
class PrimoAlpineContext {
    constructor() {
        this.config = inject(PRIMO_ALPINE_CONFIG, { optional: true }) ?? {};
        this.zone = inject(NgZone);
        this.primo = inject(PrimoStateService);
        this.translateService = inject(TranslateService, { optional: true });
        this.i18n = getAlpine().reactive({ tick: 0 });
        this.bridge = new PrimoBridge(this.primo, {
            reactive: getAlpine().reactive,
            dev: this.dev,
            runOutside: (fn) => this.zone.runOutsideAngular(fn),
        });
        const t = this.translateService;
        if (t) {
            this.zone.runOutsideAngular(() => merge(t.onLangChange, t.onTranslationChange, t.onDefaultLangChange).subscribe(() => this.i18n.tick++));
        }
        if (this.dev && this.config.tokenInspector !== false && new URLSearchParams(location.search).has('ndeTokens')) {
            import('@libis/primo-alpine/tokens')
                .then(({ mountTokenInspector }) => mountTokenInspector(getAlpine()))
                .catch((err) => console.error('[primo-alpine] token inspector failed to load', err));
        }
    }
    get dev() {
        return !!this.config.dev;
    }
    /** `$t`: `TranslateService.instant`, re-evaluated by Alpine when the language or translations change. */
    translate(key, params) {
        void this.i18n.tick;
        if (!this.translateService)
            return key;
        const value = this.translateService.instant(key, params);
        return typeof value === 'string' ? value : key;
    }
    /** `$asset` / `x-asset-src`: prefixes `assets/...` paths with the remote's public path. */
    asset(url) {
        if (!url || /^(https?:)?\/\//i.test(url) || /^(data|blob):/i.test(url))
            return url;
        const clean = url.startsWith('/') ? url.slice(1) : url;
        if (!clean.startsWith('assets/'))
            return url;
        const base = this.config.assetBase?.() ?? '';
        return (base && !base.endsWith('/') ? `${base}/` : base) + clean;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: PrimoAlpineContext, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: PrimoAlpineContext, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: PrimoAlpineContext, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

/** Unwraps a signal input; plain fields pass through. */
const read = (value) => (isSignal(value) ? value() : value);
/**
 * The single place that knows host component internals. Maps a slot (the host element name,
 * without position suffix) to where its component keeps the record. Only the record's identity
 * is taken from here; its data comes from the store (see {@link RecordTracker}).
 *
 * Verified against NDE (September 2026): on the results page records render in
 * `nde-search-result-item-container`; there is no `nde-brief-result` element. The host fields
 * are plain properties, not signal inputs, but `read` unwraps signals should that change.
 */
const RECORD_RESOLVERS = {
    'nde-record-availability': (h) => read(h?.searchResult),
    'nde-record-image': (h) => read(h?.item),
    // Not yet verified against the live host:
    'nde-full-display': (h) => read(h?.record) ?? read(h?.fullDisplayRecord) ?? read(h?.searchResult) ?? read(h?.item),
    'nde-brief-result': (h) => read(h?.searchResult) ?? read(h?.item),
};
/**
 * Keys the host store might use for this doc. NDE keys `Search.entities` by
 * `pnx.control.recordid[0]` (e.g. `alma99...`); `@id` (the PNX URL) is a fallback.
 */
function recordKeys(doc) {
    const keys = [doc?.pnx?.control?.recordid?.[0], doc?.['@id']];
    return [...new Set(keys.filter((k) => typeof k === 'string' && k.length > 0))];
}
/**
 * `$record` for one island: identity from the host component, data from `primo.search`,
 * so it updates when the host enriches the record (delivery, availability, ...). When the store
 * has no such doc (a deep-linked full display), the host component's own doc is used as-is.
 */
class RecordTracker {
    constructor(context, slot) {
        this.context = context;
        this.slot = slot;
        this.key = '';
        this.warned = false;
        this.tick = getAlpine().reactive({ n: 0 });
    }
    /** Whether `$record` means anything in this island's slot. */
    get supported() {
        return !!this.slot && this.slot in RECORD_RESOLVERS;
    }
    /** Re-resolves the record from the host component. Cheap when the record did not change. */
    update(hostComponent) {
        if (!this.supported)
            return;
        const hostDoc = RECORD_RESOLVERS[this.slot](hostComponent);
        const keys = recordKeys(hostDoc);
        const key = keys.join('|');
        if (key === this.key)
            return;
        this.key = key;
        this.subscription?.unsubscribe();
        if (!keys.length) {
            if (this.context.dev && hostComponent && !this.warned) {
                this.warned = true;
                warn(`No record id found on the ${this.slot} host component; the resolver in RECORD_RESOLVERS may be outdated.`, hostComponent);
            }
            this.set(hostDoc);
            return;
        }
        const search = this.context.primo.search;
        this.subscription = this.context.zone.runOutsideAngular(() => combineLatest(keys.map((k) => search.selectDocById$(k)))
            .pipe(map((docs) => docs.find(Boolean) ?? hostDoc))
            .subscribe((doc) => this.set(doc)));
    }
    read() {
        void this.tick.n;
        return this.value;
    }
    stop() {
        this.subscription?.unsubscribe();
        this.subscription = undefined;
        this.key = '';
    }
    set(doc) {
        if (doc === this.value)
            return;
        this.value = doc;
        this.tick.n++;
    }
}

/**
 * Base class for an Alpine island: an Angular component with an empty template whose markup
 * (`static html`) is injected after view init and handed to Alpine.
 *
 * ```ts
 * @Component({ selector: 'custom-island-summary', template: '', encapsulation: ViewEncapsulation.None })
 * export class SummaryIsland extends AlpineIsland {
 *   static override html = `<p x-data x-text="$primo.search.totalResults"></p>`;
 * }
 * ```
 */
class AlpineIsland {
    constructor() {
        this.root = inject(ElementRef).nativeElement;
        this.context = inject(PrimoAlpineContext);
        this.injector = inject(Injector);
        this.record = new RecordTracker(this.context, this.constructor.slot);
        this.mounted = false;
    }
    /** Alpine markup for this island. */
    static { this.html = ''; }
    /** Set by the NDE host. Exposed raw as `$hostComponent`. */
    set hostComponent(value) {
        this.host = value;
        if (this.mounted)
            this.record.update(value);
    }
    get hostComponent() {
        return this.host;
    }
    ngAfterViewInit() {
        const island = this.constructor;
        const Alpine = getAlpine();
        runSetupOnce(island.setup);
        const self = this;
        setIslandState(this.root, {
            context: this.context,
            record: this.record,
            get hostComponent() {
                return self.host;
            },
        });
        this.context.bridge.attach();
        this.mounted = true;
        if (this.record.supported) {
            this.record.update(this.host);
            // If the host keeps its record in a signal input, a reused host instance switching
            // records re-runs this effect and $record follows.
            this.recordEffect = effect(() => this.record.update(this.host), { injector: this.injector });
        }
        if (island.island)
            this.root.setAttribute('data-island', island.island);
        this.root.innerHTML = island.html;
        this.context.zone.runOutsideAngular(() => Alpine.initTree(this.root));
    }
    ngOnDestroy() {
        if (!this.mounted)
            return;
        this.mounted = false;
        getAlpine().destroyTree(this.root);
        this.recordEffect?.destroy();
        this.record.stop();
        this.context.bridge.detach();
        setIslandState(this.root, undefined);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: AlpineIsland, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: AlpineIsland, isStandalone: true, inputs: { hostComponent: "hostComponent" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: AlpineIsland, decorators: [{
            type: Directive
        }], propDecorators: { hostComponent: [{
                type: Input
            }] } });

/*
 * Public API of @libis/primo-alpine
 */
// @libis/primo-shared-state is compiled with tsc decorators; Angular reads its constructor
// parameters from reflect-metadata, which must load before that package does.

/**
 * Generated bundle index. Do not edit.
 */

export { AlpineIsland, PRIMO_ALPINE_CONFIG, PRIMO_DOMAINS, PrimoAlpineContext, PrimoBridge, RECORD_RESOLVERS, RecordTracker, getAlpine, providePrimoAlpine, recordKeys, runSetupOnce, selectorKeys, selectorName };
//# sourceMappingURL=libis-primo-alpine.mjs.map
