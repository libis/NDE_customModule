import { PrimoDomain, PrimoView } from './types';
/** The part of `PrimoStateService` the bridge needs: one object per domain. */
export type PrimoStateLike = {
    readonly [D in PrimoDomain]: object;
};
export interface BridgeOptions {
    /** Alpine's `reactive` (or any compatible reactivity function). Used only for tick counters. */
    reactive: <T extends object>(target: T) => T;
    /** Dev mode: deep-freeze emitted values and warn about unknown keys. */
    dev?: boolean;
    /** Wraps subscribe calls, e.g. `NgZone.runOutsideAngular`. */
    runOutside?: <T>(fn: () => T) => T;
}
export declare function selectorName(key: string): string;
/** Lists the `$primo` keys a state service offers: every zero-argument `selectFoo$()` method. */
export declare function selectorKeys(service: object): string[];
/**
 * Connects `PrimoStateService` observables to Alpine's reactivity.
 *
 * - `$primo.<domain>.<name>` maps to `primo.<domain>.select<Name>$()`.
 * - Subscriptions are lazy (made on first read) and all released when the last island detaches.
 * - Values are kept raw; Alpine tracks a per-key tick counter instead of the value itself.
 * - The view is read-only: assignments and deletes throw.
 */
export declare class PrimoBridge {
    private readonly primo;
    private readonly options;
    readonly view: PrimoView;
    private readonly entries;
    private readonly ticks;
    private readonly warned;
    private readonly domainViews;
    private islands;
    constructor(primo: PrimoStateLike, options: BridgeOptions);
    /** Called by each island when it mounts. */
    attach(): void;
    /** Called by each island when it is destroyed. The last one out releases every subscription. */
    detach(): void;
    /** Keys that currently hold a live subscription (for tests and debugging). */
    get activeKeys(): string[];
    get attachedIslands(): number;
    /** Reads one key, subscribing on first use. Tracked by the calling Alpine effect. */
    read(domain: PrimoDomain, key: string): unknown;
    private subscribe;
    private releaseAll;
    private domain;
    private selector;
    private createRootView;
    private domainView;
}
//# sourceMappingURL=bridge.d.ts.map