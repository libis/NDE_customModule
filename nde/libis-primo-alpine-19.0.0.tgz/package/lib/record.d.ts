import type { Doc } from '@libis/primo-shared-state';
import type { PrimoAlpineContext } from './context';
/** Returns the record a host component holds, or `undefined`. May read signals. */
export type RecordResolver = (hostComponent: any) => Doc | undefined;
/**
 * The single place that knows host component internals. Maps a slot (the host element name,
 * without position suffix) to where its component keeps the record. Only the record's identity
 * is taken from here; its data comes from the store (see {@link RecordTracker}).
 *
 * Verified against NDE (September 2026): on the results page records render in
 * `nde-search-result-item-container`; there is no `nde-brief-result` element. The host fields
 * are plain properties, not signal inputs, but `read` unwraps signals should that change.
 */
export declare const RECORD_RESOLVERS: Record<string, RecordResolver>;
/**
 * Keys the host store might use for this doc. NDE keys `Search.entities` by
 * `pnx.control.recordid[0]` (e.g. `alma99...`); `@id` (the PNX URL) is a fallback.
 */
export declare function recordKeys(doc: Doc | undefined): string[];
/**
 * `$record` for one island: identity from the host component, data from `primo.search`,
 * so it updates when the host enriches the record (delivery, availability, ...). When the store
 * has no such doc (a deep-linked full display), the host component's own doc is used as-is.
 */
export declare class RecordTracker {
    private readonly context;
    private readonly slot;
    private value;
    private key;
    private subscription?;
    private warned;
    private readonly tick;
    constructor(context: PrimoAlpineContext, slot: string | undefined);
    /** Whether `$record` means anything in this island's slot. */
    get supported(): boolean;
    /** Re-resolves the record from the host component. Cheap when the record did not change. */
    update(hostComponent: unknown): void;
    read(): Doc | undefined;
    stop(): void;
    private set;
}
//# sourceMappingURL=record.d.ts.map