import { AfterViewInit, OnDestroy } from '@angular/core';
import { AlpineType } from './alpine';
import * as i0 from "@angular/core";
/**
 * Base class for an Alpine island: an Angular component with an empty template whose markup
 * (`static html`) is injected after view init and handed to Alpine.
 *
 * ```ts
 * @Component({ selector: 'custom-island-summary', template: '', encapsulation: ViewEncapsulation.None })
 * export class SummaryIsland extends AlpineIsland {
 *   static override html = `<p x-data x-text="$primo.search.totalResults"></p>`;
 * }
 * ```
 */
export declare abstract class AlpineIsland implements AfterViewInit, OnDestroy {
    /** Alpine markup for this island. */
    static html: string;
    /**
     * Island name, set as `data-island` on the root element. The host decides the custom element's
     * tag name, so island styles are scoped with `[data-island="<name>"]` rather than a tag selector.
     */
    static island?: string;
    /** The host slot this island is attached to (e.g. `nde-record-availability`); enables `$record`. */
    static slot?: string;
    /** Optional one-time registration (`Alpine.data`, `Alpine.store`), usually the default export of `logic.js`. */
    static setup?: (Alpine: AlpineType) => void;
    private readonly root;
    private readonly context;
    private readonly injector;
    private readonly record;
    private recordEffect?;
    private host;
    private mounted;
    /** Set by the NDE host. Exposed raw as `$hostComponent`. */
    set hostComponent(value: unknown);
    get hostComponent(): unknown;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlpineIsland, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AlpineIsland, never, never, { "hostComponent": { "alias": "hostComponent"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=island.d.ts.map