import type { AlpineType } from './alpine';
/**
 * True when this bundle's async functions were downleveled. Our own module is transpiled exactly
 * like Alpine's, so if our `async function` is not a real one, neither is Alpine's.
 */
export declare function asyncIsDownleveled(): boolean;
/**
 * Whether Alpine's current evaluator fails on a trivial expression. False for the CSP build (its
 * own interpreter) and for bundles that kept native async, so those are never touched.
 */
export declare function alpineEvaluatorIsBroken(Alpine: AlpineType): boolean;
/**
 * Replaces Alpine's evaluator and raw evaluator with line-for-line ports of Alpine 3.17's
 * `normalEvaluator` / `normalRawEvaluator` that use the real AsyncFunction.
 *
 * One behaviour cannot be reproduced: Alpine's internal `dontAutoEvaluateFunctions` flag, which
 * only `Alpine.extractProp` sets (for inline bindings read by some plugins). Here functions
 * returned by an expression are always called, which is Alpine's default everywhere else.
 */
export declare function installAsyncSafeEvaluator(Alpine: AlpineType): void;
//# sourceMappingURL=evaluator.d.ts.map