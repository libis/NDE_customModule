import type * as AlpineTypings from 'alpinejs';
/** Alpine's API. @types/alpinejs stops at 3.13, so 3.14+ additions used here are added. */
export type AlpineType = AlpineTypings.Alpine & {
    setErrorHandler(handler: (error: Error, el: Element, expression?: string) => void): void;
};
/**
 * Returns the one Alpine instance islands use on this page, registering the primo magics once.
 *
 * Several remotes (central package plus a view package) can each bundle primo-alpine. The first
 * one to run claims the page; the others reuse its Alpine so magics, `Alpine.data` registrations
 * and stores are shared, and nothing is configured twice.
 *
 * `Alpine.start()` is never called: it would observe mutations on the whole Primo document.
 * Islands are initialised and destroyed explicitly with `initTree` / `destroyTree`.
 *
 * When Alpine's evaluator is broken because the bundler downleveled async/await (Angular with
 * zone.js), it is replaced by one that uses the real AsyncFunction; see evaluator.ts.
 */
export declare function getAlpine(): AlpineType;
/** Runs an island's `logic.js` registration once per page, however many instances mount. */
export declare function runSetupOnce(setup: ((Alpine: AlpineType) => void) | undefined): void;
//# sourceMappingURL=alpine.d.ts.map