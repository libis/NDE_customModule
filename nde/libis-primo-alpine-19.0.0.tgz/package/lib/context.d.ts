import { InjectionToken, NgZone, Provider } from '@angular/core';
import { PrimoStateService } from '@libis/primo-shared-state';
import { PrimoBridge } from './bridge';
import * as i0 from "@angular/core";
export interface PrimoAlpineConfig {
    /** Dev mode: deep-freeze host values, warn about unknown `$primo` keys and missing records. */
    dev?: boolean;
    /**
     * Base URL for `assets/...` paths, read on every call. In a webpack remote pass
     * `() => __webpack_public_path__` so central and view packages each resolve their own assets.
     */
    assetBase?: () => string;
    /**
     * Mount the design-token inspector when the page URL has `?ndeTokens=1`. Only in dev mode, and
     * loaded lazily, so it never reaches production users. Default: true.
     */
    tokenInspector?: boolean;
}
export declare const PRIMO_ALPINE_CONFIG: InjectionToken<PrimoAlpineConfig>;
export declare function providePrimoAlpine(config: PrimoAlpineConfig): Provider[];
/**
 * Per-remote services the islands share: the `$primo` bridge, translation and asset resolution.
 * One instance per remote injector; the Alpine instance itself is shared page-wide.
 */
export declare class PrimoAlpineContext {
    readonly config: PrimoAlpineConfig;
    readonly zone: NgZone;
    readonly primo: PrimoStateService;
    readonly bridge: PrimoBridge;
    private readonly translateService;
    private readonly i18n;
    constructor();
    get dev(): boolean;
    /** `$t`: `TranslateService.instant`, re-evaluated by Alpine when the language or translations change. */
    translate(key: string, params?: Record<string, unknown>): string;
    /** `$asset` / `x-asset-src`: prefixes `assets/...` paths with the remote's public path. */
    asset(url: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrimoAlpineContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PrimoAlpineContext>;
}
//# sourceMappingURL=context.d.ts.map