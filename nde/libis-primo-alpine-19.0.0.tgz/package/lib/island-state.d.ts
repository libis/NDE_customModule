import type { PrimoAlpineContext } from './context';
import type { RecordTracker } from './record';
/** What the magics need to know about the island an expression runs in. */
export interface IslandState {
    readonly context: PrimoAlpineContext;
    readonly hostComponent: unknown;
    readonly record: RecordTracker;
}
export declare function setIslandState(root: Element, state: IslandState | undefined): void;
/** Finds the state of the closest island around `el` (islands can nest). */
export declare function islandStateFor(el: Element | null): IslandState | undefined;
//# sourceMappingURL=island-state.d.ts.map