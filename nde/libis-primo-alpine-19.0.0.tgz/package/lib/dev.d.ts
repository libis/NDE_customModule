/** Recursively freezes plain objects and arrays. Leaves class instances (Dates, Maps, ...) alone. */
export declare function deepFreeze<T>(value: T, seen?: WeakSet<object>): T;
export declare function warn(message: string, ...extra: unknown[]): void;
//# sourceMappingURL=dev.d.ts.map