/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@libis/primo-alpine" />
export * from './public-api';
//# sourceMappingURL=libis-primo-alpine.d.ts.map