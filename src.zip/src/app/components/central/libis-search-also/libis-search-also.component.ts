import { Component, computed, inject, Renderer2, signal, Signal, ViewChild } from '@angular/core';
import { PrimoStateService } from '@libis/primo-shared-state';
import { createFeatureSelector, createSelector, Store } from '@ngrx/store';
import { NDEComponent } from 'src/app/decorators/nde-component.decorator';
import { SearchParams } from '@libis/primo-shared-state'
import { LIBISSearchAlsoService, SearchAlsoLink } from './libis_searchAlso_service';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule, MatMenuTrigger } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { filter } from 'rxjs';
import { NavigationEnd, Router } from '@angular/router';

// Selectors that are not directly available from shared state
export const selectSearchState = createFeatureSelector<any>('Search');

export const selectSearchParams = createSelector(
  selectSearchState,
  (state) => state.searchParams
);

export const selectSearchMode = createSelector(
  selectSearchParams,
  searchParams => searchParams?.mode
)

@NDEComponent({selector: 'nde-search-bar-filters', position: 'top', viewPattern: /32KUL.*/})
@Component({
  selector: 'custom-libis-search-also',
  imports: [TranslateModule, MatMenuModule, MatButtonModule, MatIconModule, MatTooltipModule],
  templateUrl: './libis-search-also.component.html',
  styleUrl: './libis-search-also.component.scss'
})
export class LibisSearchAlsoComponent {
private store = inject(Store);
private isLoading: boolean = true;
tooltipTest: string = "nde.permalink.copiedTooltip";

private viewCode: Signal<string|undefined> = this.primo.config.vidSignal(); // de facto nooit undefined, want de view is ingeladen voordat je search kan uitvoeren
private searchParams: Signal<SearchParams|null> = this.primo.search.searchParamsSignal();
private curr_url = signal<string>('');

// Calculated property to track active search mode
private advancedSearch: Signal<boolean> = computed(
  () => {
    const currentParams = this.searchParams()
    return currentParams?.mode === 'advanced'
  }
);

collectionsDiscovery: Signal<boolean> = computed(
  () => {
    const route = this.curr_url();
    if(route.includes('collectionDiscovery')){
      return true;
    }
    return false;
  }
)

searchAlsoLinks: Signal<SearchAlsoLink[]> = computed(
  () => {
    console.log('Calculating search also links with view code: ', this.viewCode(), ' search params: ', this.searchParams(), ' advanced search: ', this.advancedSearch());
    return this.searchAlsoService.generateLinks(this.viewCode(), this.searchParams(), this.advancedSearch());
  }
)

constructor(
  private primo: PrimoStateService,
  private searchAlsoService: LIBISSearchAlsoService,
  private translate: TranslateService,
  private router: Router) {
    this.curr_url.set(this.router.url);
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd))
      .subscribe(() => {this.curr_url.set(this.router.url);
});
}

// syncMenuWidth(): void {
//   console.log('Syncing search also menu width with button width');
//     const source = document.querySelector('.search-also-button') as HTMLElement;
//     const target = document.querySelector('.search-also-menu') as HTMLElement;

//     if (source && target) {
//       const width = source.offsetWidth;
//       this.renderer.setStyle(target, 'width', `${width}px`);
//     }
//   }
}
